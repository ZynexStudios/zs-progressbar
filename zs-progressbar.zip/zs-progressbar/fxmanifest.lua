fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'zs-progressbar'
author 'zs-progressbar'
description 'Standalone progress bar with a single blocking Progress export'
version '1.0.0'

client_scripts {
    'client/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
