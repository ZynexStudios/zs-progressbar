-----------------------------------------------------------
-- zs-progressbar client/main.lua
--
-- exports('Progress', data) -> boolean (true = completed, false = cancelled/died)
--   data = {
--     label = string,
--     duration = ms,
--     canCancel = bool,       -- Esc/Backspace cancels
--     useWhileDead = bool,    -- if false (default), dying cancels the bar
--     disable = { move = bool, combat = bool, car = bool }
--   }
--
-- Only one progress bar can run at a time; a second call while one is
-- already active returns false immediately.
-----------------------------------------------------------

local active = false

local function RunControlDisableLoop(disable, isActiveRef)
    CreateThread(function()
        while isActiveRef() do
            if disable.move then
                DisableControlAction(0, 30, true) -- move left/right
                DisableControlAction(0, 31, true) -- move up/down
                DisableControlAction(0, 21, true) -- sprint
                DisableControlAction(0, 22, true) -- jump
            end

            if disable.combat then
                DisableControlAction(0, 24, true)  -- attack
                DisableControlAction(0, 25, true)  -- aim
                DisableControlAction(0, 140, true) -- melee light attack
                DisableControlAction(0, 141, true) -- melee heavy attack
                DisableControlAction(0, 142, true) -- melee alternate
                DisableControlAction(0, 106, true) -- vehicle attack
            end

            if disable.car then
                DisableControlAction(0, 71, true) -- vehicle accelerate
                DisableControlAction(0, 72, true) -- vehicle brake/reverse
                DisableControlAction(0, 63, true) -- vehicle steer left
                DisableControlAction(0, 64, true) -- vehicle steer right
                DisableControlAction(0, 75, true) -- exit vehicle
            end

            Wait(0)
        end
    end)
end

local function Progress(data)
    if active then return false end

    data = data or {}
    local duration = tonumber(data.duration) or 1000
    local label = data.label or ''
    local canCancel = data.canCancel or false
    local useWhileDead = data.useWhileDead or false
    local disable = data.disable or {}

    active = true
    local id = 'p' .. GetGameTimer()
    local cancelled = false

    SendNUIMessage({ action = 'start', id = id, label = label, duration = duration })

    if disable.move or disable.combat or disable.car then
        RunControlDisableLoop(disable, function() return active end)
    end

    local startTime = GetGameTimer()
    while GetGameTimer() - startTime < duration do
        Wait(0)

        if not useWhileDead and IsEntityDead(PlayerPedId()) then
            cancelled = true
            break
        end

        if canCancel and IsControlJustPressed(0, 202) then -- INPUT_FRONTEND_CANCEL (Esc/Backspace)
            cancelled = true
            break
        end
    end

    active = false
    SendNUIMessage({ action = 'stop', id = id, cancelled = cancelled })

    return not cancelled
end

exports('Progress', Progress)
exports('IsActive', function() return active end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    active = false
    SendNUIMessage({ action = 'stop' })
end)

-----------------------------------------------------------
-- Test command
-----------------------------------------------------------
RegisterCommand('testprogressbar', function()
    local finished = Progress({
        label = 'Testing progress bar...',
        duration = 5000,
        canCancel = true,
        disable = { move = true, combat = true, car = true }
    })

    print(('[zs-progressbar] test finished: %s'):format(tostring(finished)))
end, false)
