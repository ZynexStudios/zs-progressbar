const wrap = document.getElementById('wrap');
const label = document.getElementById('label');
const barFill = document.getElementById('barFill');

window.addEventListener('message', (event) => {
    const d = event.data;

    if (d.action === 'start') {
        label.textContent = d.label || '';
        barFill.style.transition = 'none';
        barFill.style.width = '0%';
        wrap.classList.remove('hidden');

        // force a reflow so the transition below animates from 0% instead
        // of jumping straight to 100%
        void barFill.offsetWidth;

        barFill.style.transition = `width ${d.duration}ms linear`;
        barFill.style.width = '100%';
    } else if (d.action === 'stop') {
        wrap.classList.add('hidden');
        barFill.style.transition = 'none';
        barFill.style.width = '0%';
    }
});
