# zs-progressbar

A fully standalone, blocking progress bar. The `Progress` export runs on
the caller's own thread and only returns once the bar finishes or is
cancelled — no callback needed.

## Installation

Copy `zs-progressbar` into `resources/` and add `ensure zs-progressbar`
to your `server.cfg`.

## Usage

```lua
local finished = exports['zs-progressbar']:Progress({
    label = 'Picking lock...',
    duration = 5000,      -- ms
    canCancel = true,      -- Esc/Backspace cancels
    useWhileDead = false,  -- dying cancels the bar (default)
    disable = {
        move = true,
        combat = true,
        car = true
    }
})

if finished then
    -- ran to completion
else
    -- cancelled, or the player died mid-action
end
```

Only one progress bar can be active at a time per client. Calling
`Progress` again while one is already running returns `false`
immediately without starting a second bar.

```lua
local busy = exports['zs-progressbar']:IsActive()
```

## Test command

Run `/testprogressbar` in-game to run a 5-second cancellable demo bar
(movement/combat/vehicle controls disabled). The result prints to the
client console (F8).

